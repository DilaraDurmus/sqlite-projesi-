package com.example.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button Kaydet;
    Button Goster;
    Button Sil;
    Button Guncelle;
    EditText ad;
    EditText soyad;
    EditText yas;
    EditText sehir;
    TextView Bilgiler;
    private veritabani v1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v1 = new veritabani(this);
        Kaydet = findViewById(R.id.buttonKayit);
        Goster = findViewById(R.id.buttonGoster);
        Sil = findViewById(R.id.buttonSil);
        Guncelle = findViewById(R.id.buttonGuncelle);
        ad = findViewById(R.id.editTextAd);
        soyad = findViewById(R.id.editTextSoyad);
        yas = findViewById(R.id.editTextYas);
        sehir = findViewById(R.id.editTextSehir);
        Bilgiler = findViewById(R.id.textViewBilgiler);



        Kaydet.setOnClickListener(view -> KayitEkle(ad.getText().toString(), soyad.getText().toString(), yas.getText().toString(), sehir.getText().toString()));

        Goster.setOnClickListener(view -> {
            Cursor crs = KayitGetir();
            KayitGoster(crs);
        });

        Sil.setOnClickListener(view -> {
            String adi = ad.getText().toString();
            KayitSil(adi);
        });

        Guncelle.setOnClickListener(view -> {
            String adi = ad.getText().toString();
            String soyadi = soyad.getText().toString();
            String yasi = yas.getText().toString();
            String sehri = sehir.getText().toString();
            KayitGuncelle(adi, soyadi, yasi, sehri);
        });
    }

    private final String[] sutunlar = {"ad","soyad","yas","sehir"};

    private Cursor KayitGetir() {
        SQLiteDatabase db = v1.getWritableDatabase();
        return db.query("OgrenciBilgi", sutunlar, null, null, null, null, null);
    }

    private void KayitGoster(Cursor goster) {
        StringBuilder builder = new StringBuilder();
        while (goster.moveToNext()) {
            @SuppressLint("Range") String add = goster.getString(goster.getColumnIndex("ad"));
            @SuppressLint("Range") String soyad = goster.getString(goster.getColumnIndex("soyad"));
            @SuppressLint("Range") String yass = goster.getString(goster.getColumnIndex("yas"));
            @SuppressLint("Range") String sehir = goster.getString(goster.getColumnIndex("sehir"));
            builder.append("Ad: ").append(add).append("\n");
            builder.append("Soyad: ").append(soyad).append("\n");
            builder.append("Yas: ").append(yass).append("\n");
            builder.append("Sehir: ").append(sehir).append("\n");
            builder.append("----------------").append("\n");
        }
        Bilgiler.setText(builder.toString());
    }

    private void KayitEkle(String adi, String soyadi, String yasi, String sehri) {
        SQLiteDatabase db = v1.getWritableDatabase();
        ContentValues veriler = new ContentValues();
        veriler.put("ad", adi);
        veriler.put("soyad", soyadi);
        veriler.put("yas", yasi);
        veriler.put("sehir", sehri);
        db.insertOrThrow("OgrenciBilgi", null, veriler);
    }

    private void KayitSil(String adi) {
        SQLiteDatabase db = v1.getReadableDatabase();
        db.delete("OgrenciBilgi", "ad" + "=?", new String[]{adi});
    }

    private void KayitGuncelle(String addd, String soyaddd, String yasss, String sehirrr) {
        SQLiteDatabase db = v1.getWritableDatabase();
        ContentValues cvGuncelle = new ContentValues();
        cvGuncelle.put("ad", addd);
        cvGuncelle.put("soyad", soyaddd);
        cvGuncelle.put("yas", yasss);
        cvGuncelle.put("sehir", sehirrr);
        db.update("OgrenciBilgi", cvGuncelle, "ad" + "=?", new String[]{addd});
        db.close();
    }
}
